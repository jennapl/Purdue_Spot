package org.smart_laboratory.desktop.finalprojectcnit355;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class SpotPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_spot_page);
    }
}